from django.shortcuts import render, get_object_or_404
from .models import Student,Category, GroupPost
# Create your views here.

categories = Category.objects.all()
groups = GroupPost.objects.all()

def index(request):
    students = Student.objects.filter(is_active=1)
    data = {
        'title':'Student Management',
        'page':"Dashboard",
        'students':students,
        'categories':categories,
        'groups':groups
    }
    
    return render(request, 'student/index.html', context=data)

def show_post(request, post_slug):
    student = get_object_or_404(Student, slug=post_slug)
    data = {
        'title':'Student Management',
        'page':"Dashboard",
        'student':student,
        'categories':categories,
        'groups':groups
    }
    return render(request, 'student/show_post.html', context=data)




def show_category(request, cat_slug):
    category = get_object_or_404(Category, slug=cat_slug)
    students = category.students.filter(is_active=1)
    data = {
        'title':'Student Management',
        'page':f"Student {category.name}",
        'students':students,
        'categories':categories,
        'groups':groups
    }
    
    return render(request, 'student/index.html', context=data)


def show_group(request, guruh_slug):
    group = get_object_or_404(GroupPost, slug=guruh_slug)
    students = group.group_student.filter(is_active=True)
    data = {
        'title':'Student Management',
        'page':f"Student {group.group_name}",
        'students':students,
        'categories':categories,
        'groups':groups
    }
    
    return render(request, 'student/index.html', context=data)