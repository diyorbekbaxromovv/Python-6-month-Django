from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('post/<slug:post_slug>/', views.show_post, name='student_post'),
    path('cat/<slug:cat_slug>/', views.show_category, name='cat'),
    path('guruh/<slug:guruh_slug>/', views.show_group, name='group')
    
]
