from django.db import models

# Create your models here.

class Student(models.Model):
    name = models.CharField(max_length=255)
    content = models.TextField(blank=True)
    slug=models.SlugField(max_length=255, unique=True, db_index=True)
    time_create = models.DateTimeField(auto_now_add=True)
    time_update = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)
    cat = models.ForeignKey('Category', on_delete=models.PROTECT, related_name = 'students')
    group = models.ManyToManyField('GroupPost', blank=True, related_name='group_student')
    
    
    
    
    def __str__(self) -> str:
        return self.name
    
    
class Category(models.Model):
    name = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255, unique=True, db_index=True) 
    
    def __str__(self) -> str:
        return self.name
    
    
class GroupPost(models.Model):
    group_name = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255, unique=True, db_index=True)
    
    
    def __str__(self) -> str:
        return self.group_name