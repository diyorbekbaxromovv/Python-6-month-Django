# Requirements 
# Step 1 

install and activate virtual environment

# Step2
create folder "config"

# Step 3 
clone this poject

# Step 4

pip install requirements.txt

