from django.contrib import admin
from .models import Computer,Category
# Register your models here.

admin.site.register([Computer,Category])
