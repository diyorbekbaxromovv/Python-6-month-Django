from django import forms
from django.core.exceptions import ValidationError 
from .models import Computer, Category


class ComputerForm(forms.ModelForm):

    
    class Meta:
        model = Computer
        fields = "__all__"

        widgets = {
            'content':forms.Textarea(attrs={'cols':50, 'rows':5})
        }
        labels = {
            'name':"Computer" 
        }
        
