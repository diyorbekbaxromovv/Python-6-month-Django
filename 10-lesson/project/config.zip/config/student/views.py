from django.shortcuts import render, redirect, get_object_or_404
from .forms import ComputerForm
from .models import Computer, Category
# Create your views here.
categories = Category.objects.all()


def index(request):
    computers = Computer.objects.all()
    data = {
        'title':'Computer Management',
        'page':'Dashboard',
        'computers':computers,
        'categories':categories
        
    }
    
    return render(request, 'student/index.html', context=data)

def show_category(request, cat_slug):
    category = get_object_or_404(Category, slug=cat_slug)
    computers = category.computers.all()
    data = {
        'title':'Computer Management',
        'page':f"Computers {category.name}",
        'computers':computers,
        'categories':categories,
    }
    
    return render(request, 'student/index.html', context=data)


def add_post(request):
    # student = Student() 
    
    if request.method == "POST":
        form = ComputerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')

    else:
        form = ComputerForm()

        
   
    
    data = {
        'title':'Student Management',
        'page':f"Student Post Add",
        'categories':categories,
        'form':form
    }
    return render(request, 'student/add_post.html', context=data)