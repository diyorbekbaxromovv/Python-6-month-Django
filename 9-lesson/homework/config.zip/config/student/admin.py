from django.contrib import admin
from .models import Student,Category,GroupPost
# Register your models here.

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'time_create', 'is_active')
    list_display_links = ('name','id')
    ordering=['id']
    list_editable = ['is_active']
    list_per_page = 5

# admin.site.register([Student, Category, GroupPost])

admin.site.site_title = "Studentlar admin paneli"
admin.site.site_header = "Student | Admin"